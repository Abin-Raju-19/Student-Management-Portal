import { useDispatch, useSelector } from 'react-redux';
import { addStudent, updateStudent } from '../redux/studentSlice';
import { useNavigate, useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';

export default function StudentForm() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = !!id;
  const students = useSelector(state => state.students.list);
  const existing = students.find(s => s.id === parseInt(id)) || {};

  const [form, setForm] = useState({ name: '', email: '', phone: '' });

  useEffect(() => {
    if (isEdit) setForm(existing);
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone) return alert("All fields required");
    if (!/\S+@\S+\.\S+/.test(form.email)) return alert("Invalid email");

    if (isEdit) {
      dispatch(updateStudent({ ...form, id: parseInt(id) }));
    } else {
      dispatch(addStudent({ ...form, id: Date.now() }));
    }
    navigate("/");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>{isEdit ? "Edit" : "Add"} Student</h2>
      <input placeholder="Full Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
      <input placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
      <input placeholder="Phone" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
      <button type="submit">{isEdit ? "Update" : "Add"} Student</button>
    </form>
  );
}
