import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setStudents, deleteStudent } from '../redux/studentSlice';
import { Link } from 'react-router-dom';
import axios from 'axios';

export default function StudentList() {
  const dispatch = useDispatch();
  const students = useSelector(state => state.students.list);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users')
      .then(res => {
        dispatch(setStudents(res.data));
        setLoading(false);
      })
      .catch(() => {
        setError('Failed to load students');
        setLoading(false);
      });
  }, [dispatch]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div>
      <h2>Student List</h2>
      <ul>
        {students.map(student => (
          <li key={student.id}>
            {student.name} - {student.email}
            <Link to={`/student/${student.id}`}> View </Link>
            <button onClick={() => {
              if (confirm('Delete student?')) {
                dispatch(deleteStudent(student.id));
              }
            }}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
