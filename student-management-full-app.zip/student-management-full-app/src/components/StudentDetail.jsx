import { useParams, Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

export default function StudentDetail() {
  const { id } = useParams();
  const student = useSelector(state =>
    state.students.list.find(s => s.id === parseInt(id))
  );

  if (!student) return <p>Student not found</p>;

  return (
    <div>
      <h2>Student Detail</h2>
      <p><strong>Name:</strong> {student.name}</p>
      <p><strong>Email:</strong> {student.email}</p>
      <p><strong>Phone:</strong> {student.phone}</p>
      <Link to="/">Back to List</Link>
    </div>
  );
}
